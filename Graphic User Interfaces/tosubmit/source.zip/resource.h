//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Comboling.rc
//
#define SND_SELECT                      103
#define SND_DONE                        105
#define SND_HIT                         106
#define IDD_DIALOG_ABOUT                106
#define SND_WRONG                       107
#define TILE_DEFAULT                    110
#define ID_PM                           112
#define IDR_WAVE1                       115
#define SND_COMPLETE                    115
#define IDD_DIALOG1                     116
#define ID_DIALOG_ABOUT                 116
#define IDI_ICON                        117
#define ID_ICON                         117
#define IDC_BUTTON1                     1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
